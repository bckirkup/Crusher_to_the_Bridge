# Crew-First Wearable Biosurveillance for Cruise Ships: A Simulation-Based Analysis of the Diagnostic Cascade Approach

**A Revision Integrating the Diagnostic Cascade and Confounder-Aware Architecture**

## 1. Abstract

Wearable biosurveillance promises early detection of maritime disease outbreaks, but raw physiological anomaly data is an insufficient basis for operational escalation. Unfiltered anomaly triggers risk the "Mask of Red Death" effect, where unnecessary cabin confinement protocols concentrate healthy and sick individuals in high-risk zones, inadvertently accelerating transmission. Utilizing the Crusher-to-the-Bridge simulation testbed (500 agents, 14 epochs, calibrated to CDC VSP median attack rates), we introduce a 4-tier Diagnostic Cascade that filters wearable alerts through confounder-aware scoring and sequential clinical validation. We demonstrate that crew-only wearable deployment is the optimal sentinel strategy. For norovirus, crew-only surveillance with the Diagnostic Cascade reduced infections by 8.0% ($p=0.0498, d=0.20$), while achieving a 40.7% reduction ($p=0.035$) for SARS-CoV-2. Crucially, the addition of passenger "Bring Your Own Device" (BYOD) wearables provided zero incremental benefit over crew-only deployment. The cascade successfully filtered background noise, processing ~275 alerts per cruise but confirming zero cases on clean voyages, preventing the 30-60% transmission increase associated with naive escalation. The software framework, including extensible pathogen and device profiles, is available for replication and extension.

## 2. Introduction

The cruise ship environment presents unique challenges for infectious disease containment. High-density passenger mixing, shared HVAC infrastructure, and rapid turnover create ideal conditions for viral transmission. Traditional syndromic surveillance relies on passengers reporting to the medical center—a lagging indicator that often occurs days after the index case has initiated exponential spread [1].

Continuous physiological monitoring via consumer wearables (e.g., smartwatches, smart rings) offers a potential solution by detecting pre-symptomatic physiological deviations, such as elevated resting heart rate, depressed heart rate variability (HRV), and temperature anomalies [2]. However, the maritime environment is uniquely noisy. Seasickness, alcohol consumption, and altered activity patterns generate physiological signatures that mimic viral prodromes. 

### 2.1 The "Mask of Red Death" Effect

A critical peril of wearable-enabled surveillance is the risk of naive escalation. If uncalibrated wearable anomalies directly trigger severe operational protocols—such as ship-wide lockdowns or mandatory cabin confinement—the intervention can paradoxically increase transmission. We term this the "Mask of Red Death" effect. In a cruise ship context, cabin confinement requires crew to deliver meals to potentially infectious passengers, increasing crew exposure. If the crew subsequently become vectors, the virus is distributed across all ship zones. Furthermore, shared HVAC returns in cabin corridors can concentrate airborne pathogens if not properly managed. 

Similar dynamics have been observed in other settings, such as Ebola care avoidance [3] and the early quarantine of the *Diamond Princess*, where delayed evacuation and on-board isolation contributed to widespread passenger and crew infection [4]. Consequently, wearable data must be treated as a screening tool, not a diagnostic endpoint. 

## 3. The Crusher-to-the-Bridge Simulation Framework

To evaluate surveillance architectures, we utilized the Crusher-to-the-Bridge (CTB) simulation framework. CTB is a bridging package that orchestrates five independent simulation domains into a unified epoch loop.

*   **Agent-Based Model (ABM):** The core utilizes the Korkin Lab `infection-dynamics` ABM, adapting its dose-response model to evaluate host-pathogen interactions across discrete agent classes.
*   **Multi-Zone Spatial Transmission:** Spread is modeled across six pathways (direct contact, short-range droplet, long-range HVAC airborne, fomite deposition, food contamination, and environmental colonization). HVAC transport employs the NIST CONTAM multi-zone mass-balance equation.
*   **Pathogen Profiles:** Dose-response parameters are grounded in quantitative microbial risk assessment (QMRA). The current study evaluated Norovirus GII.4 (Beta-Poisson, $\alpha=0.111$, $\beta=32.81$) and SARS-CoV-2.
*   **Calibration:** The simulation severity (`dose_adjustment=7.0`) was calibrated to match the median 5.6% passenger attack rate observed in historical CDC Vessel Sanitation Program (VSP) data for norovirus outbreaks.
*   **OPIR Backstop:** An Operational Impact Score quantifies the disruption caused by both the outbreak and the implemented interventions.

## 4. The Diagnostic Cascade Architecture

To safely operationalize wearable surveillance without triggering the Mask of Red Death effect, we introduce the Diagnostic Cascade—a multi-tiered escalation protocol gated by confounder-aware scoring.

### 4.1 Confounder-Aware Anomaly Scoring

Before an agent enters the cascade, their physiological data is filtered. The anomaly scorer extracts z-scores for channels such as body temperature, HRV, and resting heart rate. These are compared against known confounder templates (e.g., seasickness, alcohol consumption, exercise) using cosine similarity. If the anomaly matches a confounder template (similarity $\geq 0.7$), those channels are "explained" and excluded. An `infection_score` is calculated only from unexplained deviations. Furthermore, a fleet-downweighting mechanism suppresses channels exhibiting ship-wide anomalies, filtering out systemic noise.

### 4.2 The Four-Tier Cascade

An agent triggers entry into the cascade (Tier 0) if their `infection_score` exceeds 1.5 or if a fever is detected by any worn device. 

*   **Tier 0: Wearable Clinical Triage.** Agents identified by wearable alerts enter here. This is an implicit triage layer (Sensitivity: 0.70, Specificity: 0.60) with no financial cost or confinement. Positive agents advance to Tier 1.
*   **Tier 1: Rapid Multiplex Panel (NP / Corpsman Evaluation).** Agents from Tier 0, or those presenting directly via sick call, undergo rapid diagnostic testing (Sensitivity: 0.80, Specificity: 0.97). This tier unlocks preliminary Standard Operating Procedures (SOPs). Positive agents advance to Tier 2.
*   **Tier 2: Confirmatory Testing (qPCR).** Agents undergo confirmatory molecular testing (Sensitivity: 0.95, Specificity: 0.99). **Confinement is initiated only at this tier.** This unlocks aggressive fleet-wide protocols (e.g., if $\geq 3$ agents reach Tier 2, major operational shifts occur).
*   **Tier 3: Full SOP Execution.** Confirmed cases unlock the highest-regret protocols, finalizing the diagnostic process with near-perfect clinical certainty.

## 5. Methods

We conducted four primary simulation experiments using 500-agent ship populations tracked over 14 epochs (days), focusing on the performance of the Diagnostic Cascade and sentinel deployment strategies.

1.  **Crew vs. BYOD:** Evaluated the incremental benefit of adding passenger wearables (at varying adoption rates) on top of a mandatory crew-only deployment for both norovirus and SARS-CoV-2.
2.  **Paired Power Run (100-Cruise):** A high-power evaluation (100 matched seeds) comparing the status quo (clinical RDT and syndromic surveillance only) against a crew-only wearable deployment integrated with the Diagnostic Cascade.
3.  **Severity Sweep:** Assessed the intervention's efficacy across varying pathogen transmission severities (`dose_adjustment` from 5.0 to 8.0).
4.  **Pathogen Comparison:** Contrasted the detection and containment dynamics of norovirus (enteric, highly transmissible) against SARS-CoV-2 (respiratory).

## 6. Results

### 6.1 The Sentinels: Crew > Passengers

Our findings demonstrate that monitoring passengers adds noise without conferring additional public health benefit. Across 50 paired simulation runs, adding passenger BYOD wearables to a mandatory crew deployment produced **zero incremental reduction** in infections for both norovirus and SARS-CoV-2. 

The crew function as the ideal sentinel population. They operate in every ship zone, exhibit high inter-agent contact rates (particularly in crew-only areas and galley zones), and are subject to employer-provided occupational health mandates, avoiding the complex incentive schemes required for passenger adoption. Because the crew catch the signal first, passenger data is redundant for outbreak detection.

### 6.2 Infection Reduction (Norovirus and SARS-CoV-2)

In the 100-cruise paired evaluation (calibrated severity, dose=7.0), the crew-only wearable deployment paired with the Diagnostic Cascade demonstrated a modest but statistically significant containment benefit for norovirus:

*   **Norovirus:** The intervention prevented an average of 10.4 infections per outbreak cruise, representing an **8.0% reduction** in total cases ($p=0.0498, d=0.20$).
*   **SARS-CoV-2:** The effect was substantially stronger for SARS-CoV-2, achieving a **40.7% reduction** in mean infections ($p=0.035$). This increased efficacy is attributable to the longer pre-symptomatic window characteristic of respiratory viruses, providing the wearable cascade a larger temporal advantage to interdict transmission.

### 6.3 Detection Timing and Cascade Filtering

The wearable cascade established clinical certainty significantly earlier than the status quo. Confirmed pathogen identification (Tier 3) occurred at a **median of epoch 2 (Day 2)**. While syndromic suspicion occasionally occurred on similar timelines, the cascade provided definitive diagnostic confirmation approximately one day earlier than the status quo, enabling confident SOP execution.

Crucially, the Diagnostic Cascade effectively managed the high alert volume inherent to continuous physiological monitoring:

*   **Throughput:** The system processed an average of ~275 entries per cruise into Tier 0.
*   **Specificity:** On simulated clean cruises, the cascade successfully filtered these anomalies, confirming **0 cases** and preventing false lockdowns.
*   **Sensitivity:** On outbreak cruises, the cascade successfully escalated and confirmed an average of ~23 true positive cases.

### 6.4 The Harm of Naive Escalation

The necessity of the Diagnostic Cascade is underscored by the counterfactual: naive escalation. When wearable anomalies directly triggered high-regret protocols (confinement and fleet-wide SOPs) without confounder-aware scoring and tiered clinical validation, the simulated interventions catastrophically failed.

Naive escalation increased mean infections by **30% to 60%** relative to the baseline. For example, at a wearable specificity of 0.95, naive escalation increased mean infections from a baseline of 198.2 to 318.6 (+60.7%). This validates the Mask of Red Death hypothesis: indiscriminate confinement based on raw physiological anomalies disrupts normal population dynamics, concentrating infectious individuals with susceptible crew and passengers, thereby amplifying the outbreak.

## 7. Software Availability and Extensibility

The Crusher-to-the-Bridge software is available as a reproducible simulation platform in the user's repository. The framework is inherently modular and configuration-driven, supporting distinct profiles for pathogens, wearable devices, chronic diseases, diagnostic tiers, clinical test correlations, and vessel layouts. 

While the current study utilized a 500-agent abstraction, the platform is designed to scale to varying ship configurations. 

*   **Device Extensibility:** Wearable models are explicitly extensible. The system currently represents devices such as the Oura Ring (Generations 3, 4, and 5), Apple Watch, Garmin, and continuous glucose monitoring (CGM) patches. New devices can be integrated by defining their specific channels, noise profiles, infection response sensitivities, latencies, and confounder susceptibilities.
*   **Diagnostic Extensibility:** The Diagnostic Cascade can be customized. Users can substitute rapid multiplex panels, qPCR, metagenomic sequencing, or future diagnostics by editing tier definitions, TATs, and test costs.
*   **Cohort Extensibility:** The chronic disease and sentinel cohort models are configurable. Conditions such as Type 2 Diabetes, HIV, CKD, and COPD are included, and additional conditions can be mapped with specific prevalence rates, susceptibility modifiers, and assigned monitoring hardware (e.g., assigning CGMs specifically to diabetic cohorts).

The empirical data connecting specific wearable anomalies to specific pathogen shedding timelines remains incomplete. Consequently, CTB is not presented as a definitive predictive oracle, but rather as an open testbed. It is designed to answer critical deployment questions: what device accuracy, cascade architecture, and operational infrastructure are required before deploying continuous biosurveillance is rational? The software is available for replication, scrutiny, and extension by cruise operators, public health agencies, and device manufacturers.

## 8. Discussion and Conclusion

Continuous wearable biosurveillance offers the potential to interdict maritime outbreaks earlier than traditional syndromic methods. However, our simulation demonstrates that deploying wearables without a robust, confounder-aware filtering mechanism is actively harmful. Naive escalation based on raw physiological data triggers the Mask of Red Death effect, increasing infections by up to 60%.

The Diagnostic Cascade solves this by structuring a 4-tier pipeline that triages wearable alerts against known environmental confounders and gates high-regret interventions behind rapid clinical testing. When implemented, this architecture successfully identified outbreaks at a median of Day 2 while confirming zero false positives on clean voyages.

Furthermore, we establish that the crew—not passengers—are the necessary and sufficient sentinel population. Mandatory crew monitoring achieved an 8.0% infection reduction for norovirus and a 40.7% reduction for SARS-CoV-2; adding passenger BYOD participation yielded zero incremental benefit. This finding drastically simplifies the deployment calculus for cruise operators, shifting the paradigm from a complex, privacy-encumbered passenger insurance incentive model to a straightforward occupational health and safety deployment. 

Future work should investigate the broader return on investment of crew wearables beyond infectious disease, particularly regarding fatigue management, chronic disease monitoring, and overall occupational readiness.

## References

[1] Placeholder for CDC VSP guidelines and historical maritime outbreak reporting.
[2] Placeholder for wearable anomaly detection in respiratory and enteric infections (e.g., Radin et al., Nat Med).
[3] Placeholder for Ebola care avoidance dynamics.
[4] Placeholder for Diamond Princess quarantine transmission studies.
